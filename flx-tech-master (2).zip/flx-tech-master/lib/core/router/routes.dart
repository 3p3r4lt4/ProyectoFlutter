abstract class Routes {
  static const String WELCOME = '/welcome';
  static const String SIGN_IN = '/sign_in';
  static const String QUOTER = '/quoter';
  static const String WRAPPER = '/wrapper';
  static const String MENU = '/menu';
  
}