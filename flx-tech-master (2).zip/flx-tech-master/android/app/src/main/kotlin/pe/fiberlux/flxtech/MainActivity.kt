package pe.fiberlux.flxtech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
